from typing import List

from template.book import Book

class Member:
    def __init__(self, member_id: str, name: str):
        self.id = member_id
        self.name = name
        self.borrowed_books: List[Book] = []

    def __str__(self):
        return f"{self.id}: {self.name} (Loans: {len(self.borrowed_books)})"