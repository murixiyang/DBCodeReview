class Book:
    def __init__(self, book_id: str, title: str, author: str):
        self.id = book_id
        self.title = title
        self.author = author
        self.available = True

    def __str__(self):
        return f'{self.id}: "{self.title}" by {self.author}' + \
               (" [available]" if self.available else " [loaned]")