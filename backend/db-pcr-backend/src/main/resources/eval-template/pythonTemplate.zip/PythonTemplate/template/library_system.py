from template.book import Book
from template.member import Member

class LibrarySystem:
    def __init__(self):
        # In-memory storage
        self.catalog: dict[str, Book] = {}
        self.members: dict[str, Member] = {}

    def add_book(self, book_id: str, title: str, author: str):
        """Add a new book to the catalog."""
        # TODO:
        print(f"Book added: {book_id}")


    def register_member(self, member_id: str, name: str):
        """Register a new member."""
        # TODO:
        print(f"Member registered: {member_id}")


    def borrow_book(self, member_id: str, book_id: str):
        """Borrow a book for a member."""
        # TODO:
        print(f"Borrowed book {book_id} to {member_id}")


    def return_book(self, member_id: str, book_id: str):
        """Return a book from a member."""
        # TODO:
        print(f"Returned book {book_id} from {member_id}")


    def list_books(self):
        """List all books in the catalog."""
        # TODO:


    def list_member_loans(self, member_id: str):
        """List all books currently borrowed by a member."""
        # TODO:


# ----- CLI ------
def main():
    sys = LibrarySystem()
    print("LibrarySystem Ready. Enter commands:")

    while True:
        try:
            line = input().strip()
        except EOFError:
            break

        if line.upper() == "EXIT":
            break

        parts = line.split(" ", 1)
        cmd = parts[0].upper()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd == "ADD_BOOK":
            # expects "id;title;author"
            b = arg.split(";", 2)
            sys.add_book(b[0], b[1], b[2])

        elif cmd == "REGISTER_MEMBER":
            # expects "id;name"
            m = arg.split(";", 1)
            sys.register_member(m[0], m[1])

        elif cmd == "BORROW":
            # expects "memberId bookId"
            bor = arg.split(" ")
            sys.borrow_book(bor[0], bor[1])

        elif cmd == "RETURN":
            # expects "memberId bookId"
            ret = arg.split(" ")
            sys.return_book(ret[0], ret[1])

        elif cmd == "LIST_BOOKS":
            sys.list_books()

        elif cmd == "LIST_MEMBER":
            # expects "memberId"
            sys.list_member_loans(arg)

        else:
            print(f"Unknown command: {cmd}")

    print("Goodbye!")


if __name__ == "__main__":
    main()