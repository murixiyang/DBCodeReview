import java.util.ArrayList;
import java.util.List;

public class Member {

    private String id, name;
    private List<Book> borrowedBooks = new ArrayList<>();

    public Member(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return id + ": " + name + " (Loans: " + borrowedBooks.size() + ")";
    }

}
