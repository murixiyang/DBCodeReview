public class Book {

    private String id, title, author;
    private boolean available = true;

    public Book(String id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    public String getId() {
        return id;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean avail) {
        this.available = avail;
    }

    @Override
    public String toString() {
        return id + ": \"" + title + "\" by " + author
                + (available ? " [available]" : " [loaned]");
    }

}
