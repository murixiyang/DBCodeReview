import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LibrarySystem {

    // In-memory storage
    private Map<String, Book> catalog = new HashMap<>();
    private Map<String, Member> members = new HashMap<>();

    /** Add a new book to the catalog. */
    public void addBook(String id, String title, String author) {
        // TODO:

        System.out.println("Book added: " + id);
    }

    /** Register a new member. */
    public void registerMember(String id, String name) {
        // TODO:

        System.out.println("Member registered: " + id);
    }

    /** Borrow a book for a member. */
    public void borrowBook(String memberId, String bookId) {
        // TODO:

        System.out.println("Borrowed book " + bookId + " to " + memberId);
    }

    /** Return a book from a member. */
    public void returnBook(String memberId, String bookId) {
        // TODO:

        System.out.println("Returned book " + bookId + " from " + memberId);
    }

    /** List all books in the catalog. */
    public void listBooks() {
        // TODO:

    }

    /** List all books currently borrowed by a member. */
    public void listMemberLoans(String memberId) {
        // TODO:

    }

    // === CLI ===

    public static void main(String[] args) {
        LibrarySystem sys = new LibrarySystem();
        Scanner in = new Scanner(System.in);

        System.out.println("LibrarySystem Ready. Enter commands:");

        while (true) {
            String line = in.nextLine().trim();
            if (line.equalsIgnoreCase("EXIT"))
                break;

            String[] parts = line.split(" ", 2);
            String cmd = parts[0];
            String arg = parts.length > 1 ? parts[1] : "";

            switch (cmd.toUpperCase()) {
                case "ADD_BOOK":
                    // expects "id;title;author"
                    String[] b = arg.split(";", 3);
                    sys.addBook(b[0], b[1], b[2]);
                    break;
                case "REGISTER_MEMBER":
                    String[] m = arg.split(";", 2);
                    sys.registerMember(m[0], m[1]);
                    break;
                case "BORROW":
                    String[] bor = arg.split(" ");
                    sys.borrowBook(bor[0], bor[1]);
                    break;
                case "RETURN":
                    String[] ret = arg.split(" ");
                    sys.returnBook(ret[0], ret[1]);
                    break;
                case "LIST_BOOKS":
                    sys.listBooks();
                    break;
                case "LIST_MEMBER":
                    sys.listMemberLoans(arg);
                    break;
                default:
                    System.out.println("Unknown command: " + cmd);
            }
        }

        System.out.println("Goodbye!");
        in.close();
    }
}
